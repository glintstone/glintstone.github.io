"""Passive DRIVE//STATE assessment for Windows and Intel RealSense D435i.

This is intentionally separate from the prompted data-collection protocol.
It observes naturally occurring facial, head-pose and D435i motion signals,
builds the same two-second feature windows used during model training, and
applies the trained Random Forest continuously.

The trained estimator has two learned classes: Fine and Caution.  The
four-status display is a transparent prototype interpretation layer:

* Fine       -- the Random Forest indicates Fine and no strong pattern exists.
* Distracted -- a Caution window contains sustained away-from-neutral head or
                gaze behaviour.
* Fatigue    -- a Caution window is dominated by eye-closure behaviour.
* Critical   -- extreme driver-risk evidence occurs, or strong driver-risk
                evidence coincides with unusual calibrated vehicle motion.

The IMU provides motion context; motion by itself never produces Critical.
This is a research aid, not a medical diagnosis, crash predictor or production
safety system.
"""

from __future__ import annotations

import csv
import json
import math
import time
from collections import Counter, deque
from datetime import datetime
from pathlib import Path
from typing import Any

import cv2
import joblib
import mediapipe as mp
import numpy as np
import pandas as pd

import record_session_windows_rgb_imu_RUN as core


PROJECT_DIR = Path(__file__).resolve().parent
FACE_MODEL_PATH = PROJECT_DIR / "models" / "face_landmarker.task"
CLASSIFIER_PATH = PROJECT_DIR / "models" / "driver_state_pipeline.joblib"
SCHEMA_PATH = PROJECT_DIR / "models" / "feature_schema.json"

REPORT_DIR = PROJECT_DIR / "data" / "reports"
WINDOW_DIR = PROJECT_DIR / "data" / "assessment_windows"
VIDEO_DIR = PROJECT_DIR / "data" / "assessment_video"
for output_dir in (REPORT_DIR, WINDOW_DIR, VIDEO_DIR):
    output_dir.mkdir(parents=True, exist_ok=True)

OUTPUT_WIDTH = 960
OUTPUT_HEIGHT = 540
WINDOW_TITLE = "DRIVE//STATE Passive Assessment"
PASSIVE_BASELINE_SECONDS = 5.0
MIN_BASELINE_FACE_SAMPLES = 30
MIN_BASELINE_IMU_SAMPLES = 30
MIN_BASELINE_GAZE_SAMPLES = 15
EAR_THRESHOLD_RATIO = 0.72
WINDOW_SECONDS = 2.0
STRIDE_SECONDS = 1.0
MIN_FACE_COVERAGE = 0.50
STATUS_ORDER = ("Fine", "Distracted", "Fatigue", "Critical")

LEFT_IRIS_POINTS = (473, 474, 475, 476, 477)
RIGHT_IRIS_POINTS = (468, 469, 470, 471, 472)
LEFT_EYE_CORNERS = (362, 263)
RIGHT_EYE_CORNERS = (33, 133)
HEAD_AWAY_YAW_DEG = 24.0
HEAD_AWAY_PITCH_DEG = 18.0
GAZE_AWAY_OFFSET = 0.10

STATUS_COLOURS = {
    "Fine": (67, 255, 215),
    "Distracted": (66, 157, 255),
    "Fatigue": (86, 214, 255),
    "Critical": (82, 82, 255),
    "Signal unavailable": (160, 160, 160),
    "Establishing baseline": (67, 255, 215),
}


def clean_identifier(value: str, fallback: str) -> str:
    cleaned = "".join(character for character in value.strip() if character.isalnum() or character in "-_")
    return cleaned or fallback


def collect_assessment_metadata() -> dict[str, str]:
    print("\n" + "=" * 66)
    print("DRIVE//STATE PASSIVE LIVE ASSESSMENT")
    print("=" * 66)
    print("This mode does not ask the participant to perform scripted actions.")
    print("After a five-second passive reference period, assessment runs until")
    print("Q or Esc is pressed in the camera window.\n")

    participant_id = clean_identifier(input("Participant ID [P01]: "), "P01")
    session_id = clean_identifier(input("Session ID [S01]: "), "S01")
    vehicle = input("Vehicle / setting [unspecified]: ").strip() or "Unspecified"
    operator = input("Operator ID [anonymous]: ").strip() or "Anonymous"
    save_video_answer = input("Save an MP4 recording? [Y/n]: ").strip().lower()

    return {
        "participant_id": participant_id,
        "session_id": session_id,
        "vehicle_setting": vehicle,
        "operator_id": operator,
        "save_video": "no" if save_video_answer in {"n", "no"} else "yes",
    }


def finite_values(values: list[float | None]) -> np.ndarray:
    return np.asarray(
        [float(value) for value in values if value is not None and math.isfinite(float(value))],
        dtype=np.float64,
    )


def aggregate(values: list[float | None], prefix: str) -> dict[str, float]:
    data = finite_values(values)
    if data.size == 0:
        return {
            f"{prefix}_mean": np.nan,
            f"{prefix}_std": np.nan,
            f"{prefix}_min": np.nan,
            f"{prefix}_max": np.nan,
            f"{prefix}_range": np.nan,
            f"{prefix}_rms": np.nan,
            f"{prefix}_mean_abs_change": np.nan,
            f"{prefix}_max_abs_change": np.nan,
        }

    changes = np.abs(np.diff(data))
    return {
        f"{prefix}_mean": float(np.mean(data)),
        f"{prefix}_std": float(np.std(data, ddof=0)),
        f"{prefix}_min": float(np.min(data)),
        f"{prefix}_max": float(np.max(data)),
        f"{prefix}_range": float(np.max(data) - np.min(data)),
        f"{prefix}_rms": float(np.sqrt(np.mean(np.square(data)))),
        f"{prefix}_mean_abs_change": float(np.mean(changes)) if changes.size else 0.0,
        f"{prefix}_max_abs_change": float(np.max(changes)) if changes.size else 0.0,
    }


def basic_stats(values: list[float | None], prefix: str, include_range: bool = False) -> dict[str, float]:
    data = finite_values(values)
    result = {
        f"{prefix}_mean": float(np.mean(data)) if data.size else np.nan,
        f"{prefix}_std": float(np.std(data, ddof=0)) if data.size else np.nan,
    }
    if include_range:
        result[f"{prefix}_range"] = float(np.max(data) - np.min(data)) if data.size else np.nan
    return result


def build_feature_window(samples: list[dict[str, Any]], feature_names: list[str]) -> dict[str, float]:
    features: dict[str, float] = {}

    average_ear = [sample["average_ear"] for sample in samples]
    average_data = finite_values(average_ear)
    features.update(basic_stats(average_ear, "average_ear"))
    features["average_ear_min"] = float(np.min(average_data)) if average_data.size else np.nan
    features["average_ear_max"] = float(np.max(average_data)) if average_data.size else np.nan
    features.update(basic_stats([sample["normalized_ear"] for sample in samples], "normalized_ear"))

    face_samples = [sample for sample in samples if sample["face_detected"]]
    denominator = max(1, len(face_samples))
    features["ear_below_threshold_ratio"] = sum(bool(sample["ear_below_threshold"]) for sample in face_samples) / denominator
    features["eyes_closed_ratio"] = sum(bool(sample["eyes_closed"]) for sample in face_samples) / denominator
    features["max_closure_duration_ms"] = max(
        (float(sample["closure_duration_ms"]) for sample in face_samples),
        default=0.0,
    )
    features["blink_events"] = float(sum(int(sample["blink_event"]) for sample in samples))
    features["prolonged_closure_events"] = float(sum(int(sample["prolonged_event"]) for sample in samples))

    for axis in ("pitch", "yaw", "roll"):
        features.update(basic_stats([sample[axis] for sample in samples], axis, include_range=True))

    movement_data = finite_values([sample["head_movement"] for sample in samples])
    features.update(basic_stats([sample["head_movement"] for sample in samples], "head_movement"))
    features["head_movement_max"] = float(np.max(movement_data)) if movement_data.size else np.nan

    for channel in (
        "accel_x",
        "accel_y",
        "accel_z",
        "accel_magnitude",
        "gyro_x",
        "gyro_y",
        "gyro_z",
        "gyro_magnitude",
    ):
        features.update(aggregate([sample[channel] for sample in samples], channel))

    missing = [name for name in feature_names if name not in features]
    if missing:
        raise RuntimeError(f"Feature builder is missing: {', '.join(missing)}")
    return {name: float(features[name]) for name in feature_names}


def clamp01(value: float) -> float:
    return max(0.0, min(1.0, float(value)))


def calculate_horizontal_gaze(landmarks: Any) -> float | None:
    """Return a normalized horizontal iris position, averaged across both eyes."""

    if len(landmarks) <= max(*LEFT_IRIS_POINTS, *RIGHT_IRIS_POINTS):
        return None

    ratios: list[float] = []
    for iris_points, corners in (
        (LEFT_IRIS_POINTS, LEFT_EYE_CORNERS),
        (RIGHT_IRIS_POINTS, RIGHT_EYE_CORNERS),
    ):
        corner_x = [float(landmarks[index].x) for index in corners]
        span = max(corner_x) - min(corner_x)
        if span <= 1e-6:
            continue
        iris_x = float(np.mean([landmarks[index].x for index in iris_points]))
        ratios.append((iris_x - min(corner_x)) / span)

    if not ratios:
        return None
    return float(np.mean(ratios))


def robust_reference(values: list[float], scale_floor: float) -> tuple[float, float]:
    data = finite_values(values)
    if data.size == 0:
        return 0.0, scale_floor
    median = float(np.median(data))
    mad_scale = float(1.4826 * np.median(np.abs(data - median)))
    return median, max(mad_scale, scale_floor)


def build_imu_reference(accel_values: list[float], gyro_values: list[float]) -> dict[str, float]:
    accel_median, accel_scale = robust_reference(accel_values, 0.08)
    gyro_median, gyro_scale = robust_reference(gyro_values, 0.015)
    accel_changes = np.abs(np.diff(finite_values(accel_values)))
    gyro_changes = np.abs(np.diff(finite_values(gyro_values)))
    return {
        "accel_median": accel_median,
        "accel_scale": accel_scale,
        "gyro_median": gyro_median,
        "gyro_scale": gyro_scale,
        "accel_change_reference": max(
            float(np.percentile(accel_changes, 95)) * 5.0 if accel_changes.size else 0.0,
            0.75,
        ),
        "gyro_change_reference": max(
            float(np.percentile(gyro_changes, 95)) * 5.0 if gyro_changes.size else 0.0,
            0.12,
        ),
    }


def empty_assessment_context() -> dict[str, Any]:
    return {
        "head_state": "Waiting",
        "gaze_state": "Waiting",
        "head_away_ratio": 0.0,
        "gaze_away_ratio": 0.0,
        "yaw_mean_deg": 0.0,
        "pitch_mean_deg": 0.0,
        "motion_state": "Calibrating",
        "motion_score": 0.0,
        "accel_deviation_m_s2": 0.0,
        "rotation_rate_deg_s": 0.0,
    }


def build_assessment_context(
    samples: list[dict[str, Any]],
    imu_reference: dict[str, float],
) -> dict[str, Any]:
    pitch = finite_values([sample.get("pitch") for sample in samples])
    yaw = finite_values([sample.get("yaw") for sample in samples])
    gaze = finite_values([sample.get("gaze_offset") for sample in samples])
    accel = finite_values([sample.get("accel_magnitude") for sample in samples])
    gyro = finite_values([sample.get("gyro_magnitude") for sample in samples])

    pose_count = min(pitch.size, yaw.size)
    if pose_count:
        head_away = (np.abs(yaw[:pose_count]) >= HEAD_AWAY_YAW_DEG) | (
            np.abs(pitch[:pose_count]) >= HEAD_AWAY_PITCH_DEG
        )
        head_away_ratio = float(np.mean(head_away))
    else:
        head_away_ratio = 0.0
    gaze_away_ratio = float(np.mean(np.abs(gaze) >= GAZE_AWAY_OFFSET)) if gaze.size else 0.0

    accel_deviation = (
        float(np.max(np.abs(accel - imu_reference["accel_median"]))) if accel.size else 0.0
    )
    gyro_deviation = (
        float(np.max(np.abs(gyro - imu_reference["gyro_median"]))) if gyro.size else 0.0
    )
    accel_change = float(np.max(np.abs(np.diff(accel)))) if accel.size > 1 else 0.0
    gyro_change = float(np.max(np.abs(np.diff(gyro)))) if gyro.size > 1 else 0.0

    accel_level_score = clamp01(
        (accel_deviation - 3.0 * imu_reference["accel_scale"])
        / max(2.4, 10.0 * imu_reference["accel_scale"])
    )
    gyro_level_score = clamp01(
        (gyro_deviation - 3.0 * imu_reference["gyro_scale"])
        / max(0.65, 8.0 * imu_reference["gyro_scale"])
    )
    accel_change_score = clamp01(
        (accel_change - imu_reference["accel_change_reference"])
        / max(2.0, 3.0 * imu_reference["accel_change_reference"])
    )
    gyro_change_score = clamp01(
        (gyro_change - imu_reference["gyro_change_reference"])
        / max(0.80, 3.0 * imu_reference["gyro_change_reference"])
    )
    motion_score = max(accel_level_score, gyro_level_score, accel_change_score, gyro_change_score)

    gyro_mean = float(np.mean(gyro)) if gyro.size else 0.0
    moving_threshold = imu_reference["gyro_median"] + max(3.0 * imu_reference["gyro_scale"], 0.12)
    if motion_score >= 0.78:
        motion_state = "Sudden motion"
    elif motion_score >= 0.40 or gyro_mean >= moving_threshold:
        motion_state = "Cornering / movement"
    else:
        motion_state = "Steady"

    return {
        "head_state": "Away" if head_away_ratio >= 0.55 else "Forward",
        "gaze_state": "Away" if gaze.size and gaze_away_ratio >= 0.55 else ("Centered" if gaze.size else "Unavailable"),
        "head_away_ratio": head_away_ratio,
        "gaze_away_ratio": gaze_away_ratio,
        "yaw_mean_deg": float(np.mean(yaw)) if yaw.size else 0.0,
        "pitch_mean_deg": float(np.mean(pitch)) if pitch.size else 0.0,
        "motion_state": motion_state,
        "motion_score": motion_score,
        "accel_deviation_m_s2": accel_deviation,
        "rotation_rate_deg_s": math.degrees(float(np.max(gyro))) if gyro.size else 0.0,
    }


def interpret_status(
    features: dict[str, float],
    caution_probability: float,
    context: dict[str, Any] | None = None,
) -> tuple[str, float, float, str]:
    context = context or empty_assessment_context()
    normalized_ear = features.get("normalized_ear_mean", np.nan)
    eye_ratio = features.get("eyes_closed_ratio", 0.0)
    closure_ms = features.get("max_closure_duration_ms", 0.0)
    prolonged = features.get("prolonged_closure_events", 0.0)

    fatigue_score = max(
        clamp01((0.90 - normalized_ear) / 0.35) if math.isfinite(normalized_ear) else 0.0,
        clamp01(eye_ratio / 0.55),
        clamp01(closure_ms / 2500.0),
        clamp01(prolonged),
    )

    distraction_score = max(
        clamp01(float(context.get("head_away_ratio", 0.0)) / 0.70),
        clamp01(float(context.get("gaze_away_ratio", 0.0)) / 0.65),
    )
    motion_score = clamp01(float(context.get("motion_score", 0.0)))

    if closure_ms >= 2500:
        reason = "Prolonged eye closure reached the conservative Critical rule"
        return "Critical", fatigue_score, distraction_score, reason
    if fatigue_score >= 0.88 and distraction_score >= 0.84:
        reason = "Strong fatigue and sustained head/gaze-away evidence occurred together"
        return "Critical", fatigue_score, distraction_score, reason
    if motion_score >= 0.82 and caution_probability >= 0.72 and max(fatigue_score, distraction_score) >= 0.68:
        reason = "Strong driver-risk evidence coincided with sudden calibrated vehicle motion"
        return "Critical", fatigue_score, distraction_score, reason

    if caution_probability >= 0.50:
        if fatigue_score >= 0.52 and fatigue_score >= distraction_score + 0.08:
            reason = "Caution window contains sustained eye-closure evidence"
            return "Fatigue", fatigue_score, distraction_score, reason
        if distraction_score >= 0.58:
            reason = "Caution window contains sustained head and/or gaze-away evidence"
            return "Distracted", fatigue_score, distraction_score, reason
        if fatigue_score >= 0.60:
            return "Fatigue", fatigue_score, distraction_score, "Caution window contains eye-closure evidence"
        if motion_score >= 0.78:
            return "Fine", fatigue_score, distraction_score, "Sudden motion detected without enough driver-risk evidence"
        return "Fine", fatigue_score, distraction_score, "RF Caution was not supported by sustained eye, head or gaze evidence"

    return "Fine", fatigue_score, distraction_score, "No dominant Caution pattern in the current window"


def stabilise_status(history: deque[str], current: str) -> str:
    history.append(current)
    if current == "Critical":
        return current
    counts = Counter(history)
    return max(STATUS_ORDER, key=lambda status: (counts[status], -STATUS_ORDER.index(status)))


def draw_label(frame: np.ndarray, text: str, origin: tuple[int, int], colour: tuple[int, int, int], scale: float = 0.55) -> None:
    cv2.putText(frame, text, origin, cv2.FONT_HERSHEY_SIMPLEX, scale, colour, 2, cv2.LINE_AA)


def draw_assessment_overlay(
    frame: np.ndarray,
    status: str,
    elapsed: float,
    caution_probability: float | None,
    face_coverage: float,
    imu_ready: bool,
    reason: str,
    baseline_remaining: float,
    context: dict[str, Any],
) -> None:
    colour = STATUS_COLOURS.get(status, (255, 255, 255))
    overlay = frame.copy()
    cv2.rectangle(overlay, (0, 0), (OUTPUT_WIDTH, 108), (7, 24, 21), -1)
    cv2.rectangle(overlay, (0, OUTPUT_HEIGHT - 70), (OUTPUT_WIDTH, OUTPUT_HEIGHT), (7, 24, 21), -1)
    cv2.rectangle(overlay, (620, 108), (OUTPUT_WIDTH, OUTPUT_HEIGHT - 70), (5, 18, 15), -1)
    cv2.addWeighted(overlay, 0.88, frame, 0.12, 0, frame)
    cv2.rectangle(frame, (0, 0), (11, OUTPUT_HEIGHT), colour, -1)
    cv2.line(frame, (620, 108), (620, OUTPUT_HEIGHT - 70), (58, 82, 75), 1)

    draw_label(frame, "DRIVE//STATE  PASSIVE ASSESSMENT", (32, 32), (230, 238, 234), 0.55)
    draw_label(frame, status.upper(), (32, 82), colour, 1.18)
    draw_label(frame, f"TIME  {elapsed:06.1f}s", (770, 32), (220, 226, 223), 0.48)

    signal_colour = (67, 255, 215) if face_coverage >= MIN_FACE_COVERAGE and imu_ready else (86, 214, 255)
    draw_label(frame, f"FACE {face_coverage * 100:3.0f}%", (32, OUTPUT_HEIGHT - 42), signal_colour, 0.48)
    draw_label(frame, "IMU LIVE" if imu_ready else "IMU WAIT", (175, OUTPUT_HEIGHT - 42), signal_colour, 0.48)
    draw_label(frame, "Q / ESC  END + SAVE REPORT", (660, OUTPUT_HEIGHT - 42), (220, 226, 223), 0.43)

    draw_label(frame, "HEAD + GAZE", (648, 142), (155, 174, 168), 0.40)
    head_gaze = f"{context['head_state']} / {context['gaze_state']}"
    draw_label(frame, head_gaze, (648, 171), (236, 241, 238), 0.58)
    draw_label(
        frame,
        f"Yaw {context['yaw_mean_deg']:+.1f} deg   Pitch {context['pitch_mean_deg']:+.1f} deg",
        (648, 198),
        (168, 184, 179),
        0.38,
    )
    cv2.line(frame, (648, 218), (930, 218), (58, 82, 75), 1)

    draw_label(frame, "VEHICLE MOTION", (648, 249), (155, 174, 168), 0.40)
    motion_colour = (82, 82, 255) if context["motion_state"] == "Sudden motion" else (236, 241, 238)
    draw_label(frame, str(context["motion_state"]), (648, 278), motion_colour, 0.56)
    draw_label(
        frame,
        f"dAccel {context['accel_deviation_m_s2']:.2f} m/s2   Rotation {context['rotation_rate_deg_s']:.1f} deg/s",
        (648, 305),
        (168, 184, 179),
        0.34,
    )
    cv2.line(frame, (648, 325), (930, 325), (58, 82, 75), 1)

    draw_label(frame, "RANDOM FOREST", (648, 356), (155, 174, 168), 0.40)
    probability_text = "Waiting for 2.0 s window" if caution_probability is None else f"Caution {caution_probability * 100:5.1f}%"
    draw_label(frame, probability_text, (648, 385), (236, 241, 238), 0.56)
    draw_label(frame, "Motion is context, not a crash prediction", (648, 418), (168, 184, 179), 0.36)

    if baseline_remaining > 0:
        draw_label(frame, "PASSIVE REFERENCE", (32, 144), colour, 0.62)
        draw_label(frame, f"Face + head + gaze + IMU - {baseline_remaining:.1f}s", (32, 177), (240, 240, 240), 0.52)
        draw_label(frame, "Sit naturally while the session reference is measured", (32, 207), (180, 196, 190), 0.45)
    elif reason:
        safe_reason = reason if len(reason) <= 62 else reason[:59] + "..."
        draw_label(frame, safe_reason, (32, 142), colour, 0.48)


def create_video_writer(path: Path) -> cv2.VideoWriter:
    writer = cv2.VideoWriter(
        str(path),
        cv2.VideoWriter_fourcc(*"mp4v"),
        core.FPS,
        (OUTPUT_WIDTH, OUTPUT_HEIGHT),
    )
    if not writer.isOpened():
        raise RuntimeError("OpenCV could not create the MP4 recording.")
    return writer


def write_report(
    path: Path,
    metadata: dict[str, str],
    started_at: datetime,
    ended_at: datetime,
    predictions: list[dict[str, Any]],
    video_path: Path | None,
    windows_path: Path,
) -> None:
    duration = max(0.0, (ended_at - started_at).total_seconds())
    status_counts = Counter(item["status"] for item in predictions)
    dominant_status = status_counts.most_common(1)[0][0] if status_counts else "No valid assessment"
    max_caution = max((float(item["rf_caution_probability"]) for item in predictions), default=0.0)
    max_motion = max((float(item["motion_score"]) for item in predictions), default=0.0)
    sudden_motion_windows = sum(item.get("motion_state") == "Sudden motion" for item in predictions)

    lines = [
        "DRIVE//STATE PASSIVE ASSESSMENT REPORT",
        "=" * 42,
        f"Participant ID: {metadata['participant_id']}",
        f"Session ID: {metadata['session_id']}",
        f"Vehicle / setting: {metadata['vehicle_setting']}",
        f"Operator ID: {metadata['operator_id']}",
        f"Started: {started_at.isoformat(timespec='seconds')}",
        f"Ended: {ended_at.isoformat(timespec='seconds')}",
        f"Duration: {duration:.1f} seconds",
        "",
        "SUMMARY",
        "-------",
        f"Valid two-second assessment windows: {len(predictions)}",
        f"Dominant displayed status: {dominant_status}",
        f"Maximum Random Forest Caution probability: {max_caution * 100:.1f}%",
        f"Maximum calibrated motion score: {max_motion * 100:.1f}%",
        f"Sudden-motion context windows: {sudden_motion_windows}",
    ]
    for status in STATUS_ORDER:
        count = status_counts.get(status, 0)
        percentage = (count / len(predictions) * 100.0) if predictions else 0.0
        lines.append(f"{status}: {count} windows ({percentage:.1f}%)")

    lines.extend(
        [
            "",
            "OUTPUT FILES",
            "------------",
            f"Assessment windows: {windows_path}",
            f"MP4 video: {video_path if video_path is not None else 'Not requested'}",
            "",
            "MODEL AND INTERPRETATION BOUNDARY",
            "---------------------------------",
            "The trained Random Forest learns Fine versus Caution from 87 visual-inertial features.",
            "Distracted, Fatigue and Critical are transparent prototype interpretations using sustained",
            "eye, head and gaze evidence plus session-calibrated D435i motion context. Unusual IMU motion",
            "can reflect cornering, braking, impact, road vibration or camera movement. Motion alone never",
            "produces Critical and this prototype does not predict crashes. These labels are not separately",
            "trained four-class predictions. Collect participant-separated four-class labels and retrain",
            "before treating those interpretations as validated classes.",
            "",
            "Research prototype only; not a medical diagnosis or production-certified safety system.",
        ]
    )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    for required_path in (FACE_MODEL_PATH, CLASSIFIER_PATH, SCHEMA_PATH):
        if not required_path.exists():
            raise FileNotFoundError(f"Required assessment asset not found: {required_path}")

    metadata = collect_assessment_metadata()
    with SCHEMA_PATH.open("r", encoding="utf-8") as schema_file:
        schema = json.load(schema_file)
    feature_names = list(schema["features"])
    if float(schema["window_seconds"]) != WINDOW_SECONDS or float(schema["stride_seconds"]) != STRIDE_SECONDS:
        raise RuntimeError("The packaged feature schema does not match the live window settings.")

    classifier = joblib.load(CLASSIFIER_PATH)
    class_values = [int(value) for value in classifier.classes_]
    if class_values != [0, 1]:
        raise RuntimeError(f"Expected Random Forest classes [0, 1], received {class_values}.")

    date_code = datetime.now().strftime("%Y%m%d_%H%M%S")
    prefix = f"{metadata['session_id']}_{metadata['participant_id']}_{date_code}"
    report_path = REPORT_DIR / f"{prefix}_assessment.txt"
    windows_path = WINDOW_DIR / f"{prefix}_windows.csv"
    video_path = VIDEO_DIR / f"{prefix}.mp4" if metadata["save_video"] == "yes" else None

    print("\nOutput files")
    print(f"Report:  {report_path}")
    print(f"Windows: {windows_path}")
    print(f"Video:   {video_path if video_path is not None else 'disabled'}")

    options = mp.tasks.vision.FaceLandmarkerOptions(
        base_options=mp.tasks.BaseOptions(model_asset_path=str(FACE_MODEL_PATH)),
        running_mode=mp.tasks.vision.RunningMode.VIDEO,
        num_faces=1,
        min_face_detection_confidence=0.5,
        min_face_presence_confidence=0.5,
        min_tracking_confidence=0.5,
        output_face_blendshapes=False,
        output_facial_transformation_matrixes=True,
    )

    capture = core.create_realsense_capture()
    video_writer = create_video_writer(video_path) if video_path is not None else None
    sample_buffer: deque[dict[str, Any]] = deque()
    status_history: deque[str] = deque(maxlen=3)
    predictions: list[dict[str, Any]] = []
    tracker = core.EyeEventTracker()

    baseline_ear_values: list[float] = []
    baseline_pitch_values: list[float] = []
    baseline_yaw_values: list[float] = []
    baseline_roll_values: list[float] = []
    baseline_gaze_values: list[float] = []
    baseline_accel_values: list[float] = []
    baseline_gyro_values: list[float] = []
    baseline_ready = False
    open_baseline = 0.0
    neutral_pitch = neutral_yaw = neutral_roll = 0.0
    neutral_gaze: float | None = None
    imu_reference = build_imu_reference([], [])
    ear_threshold = 0.0
    smoothed_pitch: float | None = None
    smoothed_yaw: float | None = None
    smoothed_roll: float | None = None

    started_at = datetime.now()
    program_start = time.monotonic()
    baseline_start = program_start
    last_prediction_at = program_start
    last_status = "Establishing baseline"
    last_reason = ""
    last_caution_probability: float | None = None
    last_context = empty_assessment_context()
    previous_timestamp_ms = -1
    color_sequence = 0
    first_color_packet = None

    print("\nNo scripted participant actions are required.")
    print("A five-second passive reference is estimated while the participant behaves naturally.")
    print("The assessment then runs continuously. Press Q or Esc in the preview to finish.\n")

    window_fieldnames = [
        "recorded_at",
        "elapsed_seconds",
        "status",
        "rf_fine_probability",
        "rf_caution_probability",
        "fatigue_pattern",
        "distraction_pattern",
        "face_coverage",
        "head_state",
        "gaze_state",
        "head_away_ratio",
        "gaze_away_ratio",
        "motion_state",
        "motion_score",
        "accel_deviation_m_s2",
        "rotation_rate_deg_s",
        "reason",
        *feature_names,
    ]

    try:
        cv2.namedWindow(WINDOW_TITLE, cv2.WINDOW_NORMAL)
        cv2.resizeWindow(WINDOW_TITLE, OUTPUT_WIDTH, OUTPUT_HEIGHT)
        cv2.moveWindow(WINDOW_TITLE, 40, 40)
        topmost_property = getattr(cv2, "WND_PROP_TOPMOST", None)
        if topmost_property is not None:
            cv2.setWindowProperty(WINDOW_TITLE, topmost_property, 1)

        waiting = np.zeros((OUTPUT_HEIGHT, OUTPUT_WIDTH, 3), dtype=np.uint8)
        draw_label(waiting, "D435i CONNECTED", (35, 235), STATUS_COLOURS["Fine"], 1.0)
        draw_label(waiting, "Waiting for independent RGB and IMU samples...", (35, 285), (230, 238, 234), 0.62)
        draw_label(waiting, "No participant action is required.", (35, 325), (180, 190, 186), 0.52)
        cv2.imshow(WINDOW_TITLE, waiting)
        cv2.waitKey(1)

        first_deadline = time.monotonic() + 20.0
        while first_color_packet is None:
            first_color_packet = capture.poll_color(color_sequence)
            if first_color_packet is not None:
                break
            if time.monotonic() >= first_deadline:
                raise RuntimeError(
                    "The D435i opened but RGB did not deliver a frame within 20 seconds. "
                    "Close RealSense Viewer and other camera apps, then reconnect through USB 3."
                )
            key = cv2.waitKey(30) & 0xFF
            if key in (ord("q"), 27):
                return

        with windows_path.open("w", newline="", encoding="utf-8") as windows_file:
            windows_writer = csv.DictWriter(windows_file, fieldnames=window_fieldnames)
            windows_writer.writeheader()

            with mp.tasks.vision.FaceLandmarker.create_from_options(options) as landmarker:
                while True:
                    if first_color_packet is not None:
                        packet = first_color_packet
                        first_color_packet = None
                    else:
                        packet = capture.wait_for_color(color_sequence, timeout_seconds=10.0)

                    (
                        color_sequence,
                        full_frame,
                        _colour_timestamp_ms,
                        latest_accel,
                        _accel_timestamp_ms,
                        latest_gyro,
                        _gyro_timestamp_ms,
                    ) = packet

                    now = time.monotonic()
                    elapsed = now - program_start
                    frame = cv2.resize(full_frame, (OUTPUT_WIDTH, OUTPUT_HEIGHT), interpolation=cv2.INTER_AREA)
                    clean_frame = frame.copy()
                    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                    mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb_frame)

                    timestamp_ms = max(int(elapsed * 1000), previous_timestamp_ms + 1)
                    previous_timestamp_ms = timestamp_ms
                    result = landmarker.detect_for_video(mp_image, timestamp_ms)

                    face_detected = bool(result.face_landmarks)
                    matrices = getattr(result, "facial_transformation_matrixes", [])
                    head_pose_detected = bool(face_detected and matrices)
                    average_ear: float | None = None
                    gaze_ratio: float | None = None
                    raw_pitch = raw_yaw = raw_roll = None
                    pitch = yaw = roll = head_movement = None

                    if face_detected:
                        landmarks = result.face_landmarks[0]
                        core.draw_eye_points(frame, landmarks, core.LEFT_EYE_POINTS)
                        core.draw_eye_points(frame, landmarks, core.RIGHT_EYE_POINTS)
                        left_ear = core.calculate_ear(landmarks, core.LEFT_EYE_POINTS)
                        right_ear = core.calculate_ear(landmarks, core.RIGHT_EYE_POINTS)
                        average_ear = (left_ear + right_ear) / 2.0
                        gaze_ratio = calculate_horizontal_gaze(landmarks)

                    if head_pose_detected:
                        raw_pitch, raw_yaw, raw_roll = core.extract_head_pose(matrices[0])

                    accel_x = accel_y = accel_z = accel_magnitude = None
                    if latest_accel is not None:
                        accel_x, accel_y, accel_z = latest_accel
                        accel_magnitude = float(np.linalg.norm(latest_accel))
                    gyro_x = gyro_y = gyro_z = gyro_magnitude = None
                    if latest_gyro is not None:
                        gyro_x, gyro_y, gyro_z = latest_gyro
                        gyro_magnitude = float(np.linalg.norm(latest_gyro))
                    imu_ready = latest_accel is not None and latest_gyro is not None

                    baseline_remaining = max(0.0, PASSIVE_BASELINE_SECONDS - (now - baseline_start))
                    if not baseline_ready:
                        if average_ear is not None and core.VALID_EAR_MIN < average_ear < core.VALID_EAR_MAX:
                            baseline_ear_values.append(average_ear)
                        if raw_pitch is not None and raw_yaw is not None and raw_roll is not None:
                            baseline_pitch_values.append(raw_pitch)
                            baseline_yaw_values.append(raw_yaw)
                            baseline_roll_values.append(raw_roll)
                        if gaze_ratio is not None and math.isfinite(gaze_ratio):
                            baseline_gaze_values.append(gaze_ratio)
                        if accel_magnitude is not None:
                            baseline_accel_values.append(accel_magnitude)
                        if gyro_magnitude is not None:
                            baseline_gyro_values.append(gyro_magnitude)

                        if baseline_remaining <= 0:
                            face_reference_ready = (
                                len(baseline_ear_values) >= MIN_BASELINE_FACE_SAMPLES
                                and len(baseline_yaw_values) >= MIN_BASELINE_FACE_SAMPLES
                            )
                            imu_reference_ready = (
                                len(baseline_accel_values) >= MIN_BASELINE_IMU_SAMPLES
                                and len(baseline_gyro_values) >= MIN_BASELINE_IMU_SAMPLES
                            )
                            if not face_reference_ready or not imu_reference_ready:
                                baseline_start = now
                                baseline_ear_values.clear()
                                baseline_pitch_values.clear()
                                baseline_yaw_values.clear()
                                baseline_roll_values.clear()
                                baseline_gaze_values.clear()
                                baseline_accel_values.clear()
                                baseline_gyro_values.clear()
                                baseline_remaining = PASSIVE_BASELINE_SECONDS
                                if not face_reference_ready:
                                    last_reason = "Reference restarted - improve lighting and keep the face visible"
                                else:
                                    last_reason = "Reference restarted - waiting for both D435i motion streams"
                            else:
                                sorted_ears = np.sort(np.asarray(baseline_ear_values, dtype=np.float64))
                                high_ear_start = int(len(sorted_ears) * 0.60)
                                open_baseline = float(np.median(sorted_ears[high_ear_start:]))
                                ear_threshold = open_baseline * EAR_THRESHOLD_RATIO
                                neutral_pitch = float(np.median(baseline_pitch_values))
                                neutral_yaw = float(np.median(baseline_yaw_values))
                                neutral_roll = float(np.median(baseline_roll_values))
                                neutral_gaze = (
                                    float(np.median(baseline_gaze_values))
                                    if len(baseline_gaze_values) >= MIN_BASELINE_GAZE_SAMPLES
                                    else None
                                )
                                imu_reference = build_imu_reference(baseline_accel_values, baseline_gyro_values)
                                baseline_ready = True
                                baseline_remaining = 0.0
                                tracker.reset_all()
                                sample_buffer.clear()
                                last_prediction_at = now
                                last_status = "Fine"
                                last_reason = "Passive reference established; live assessment running"
                                print(
                                    "Passive reference ready: "
                                    f"EAR {open_baseline:.3f}, threshold {ear_threshold:.3f}, "
                                    f"neutral pose ({neutral_pitch:.1f}, {neutral_yaw:.1f}, {neutral_roll:.1f}), "
                                    f"gaze {'ready' if neutral_gaze is not None else 'unavailable'}, "
                                    f"accel {imu_reference['accel_median']:.2f} m/s2, "
                                    f"gyro {math.degrees(imu_reference['gyro_median']):.1f} deg/s."
                                )

                    normalized_ear = average_ear / open_baseline if baseline_ready and average_ear is not None and open_baseline > 0 else None
                    gaze_offset = (
                        gaze_ratio - neutral_gaze
                        if baseline_ready and gaze_ratio is not None and neutral_gaze is not None
                        else None
                    )
                    eye_state = tracker.update(face_detected, average_ear, ear_threshold, timestamp_ms) if baseline_ready else {
                        "ear_below_threshold": False,
                        "eyes_closed": False,
                        "closure_event": "",
                    }

                    if baseline_ready and raw_pitch is not None and raw_yaw is not None and raw_roll is not None:
                        relative_pitch = core.wrapped_angle_difference(raw_pitch, neutral_pitch)
                        relative_yaw = core.wrapped_angle_difference(raw_yaw, neutral_yaw)
                        relative_roll = core.wrapped_angle_difference(raw_roll, neutral_roll)
                        smoothed_pitch = core.smooth_head_angle(smoothed_pitch, relative_pitch)
                        smoothed_yaw = core.smooth_head_angle(smoothed_yaw, relative_yaw)
                        smoothed_roll = core.smooth_head_angle(smoothed_roll, relative_roll)
                        pitch, yaw, roll = smoothed_pitch, smoothed_yaw, smoothed_roll
                        head_movement = float(np.linalg.norm([pitch, yaw, roll]))
                    elif baseline_ready:
                        smoothed_pitch = smoothed_yaw = smoothed_roll = None

                    if baseline_ready:
                        sample_buffer.append(
                            {
                                "time": now,
                                "face_detected": face_detected,
                                "average_ear": average_ear,
                                "normalized_ear": normalized_ear,
                                "ear_below_threshold": bool(eye_state["ear_below_threshold"]),
                                "eyes_closed": bool(eye_state["eyes_closed"]),
                                "closure_duration_ms": tracker.current_duration_ms,
                                "blink_event": int(eye_state["closure_event"] == "Blink"),
                                "prolonged_event": int(eye_state["closure_event"] == "Prolonged_Closure"),
                                "pitch": pitch,
                                "yaw": yaw,
                                "roll": roll,
                                "head_movement": head_movement,
                                "gaze_offset": gaze_offset,
                                "accel_x": accel_x,
                                "accel_y": accel_y,
                                "accel_z": accel_z,
                                "accel_magnitude": accel_magnitude,
                                "gyro_x": gyro_x,
                                "gyro_y": gyro_y,
                                "gyro_z": gyro_z,
                                "gyro_magnitude": gyro_magnitude,
                            }
                        )
                        while sample_buffer and now - sample_buffer[0]["time"] > WINDOW_SECONDS:
                            sample_buffer.popleft()

                        window_span = sample_buffer[-1]["time"] - sample_buffer[0]["time"] if len(sample_buffer) >= 2 else 0.0
                        if now - last_prediction_at >= STRIDE_SECONDS and window_span >= WINDOW_SECONDS - 0.12:
                            window_samples = list(sample_buffer)
                            face_coverage = sum(sample["face_detected"] for sample in window_samples) / max(1, len(window_samples))
                            last_prediction_at = now

                            if face_coverage >= MIN_FACE_COVERAGE and imu_ready:
                                features = build_feature_window(window_samples, feature_names)
                                context = build_assessment_context(window_samples, imu_reference)
                                feature_frame = pd.DataFrame([features], columns=feature_names)
                                probabilities = classifier.predict_proba(feature_frame)[0]
                                fine_probability = float(probabilities[class_values.index(0)])
                                caution_probability = float(probabilities[class_values.index(1)])
                                interpreted, fatigue_score, distraction_score, reason = interpret_status(
                                    features,
                                    caution_probability,
                                    context,
                                )
                                stable_status = stabilise_status(status_history, interpreted)
                                last_status = stable_status
                                last_reason = reason
                                last_caution_probability = caution_probability
                                last_context = context

                                prediction_row = {
                                    "recorded_at": datetime.now().isoformat(timespec="milliseconds"),
                                    "elapsed_seconds": round(elapsed, 3),
                                    "status": stable_status,
                                    "rf_fine_probability": round(fine_probability, 6),
                                    "rf_caution_probability": round(caution_probability, 6),
                                    "fatigue_pattern": round(fatigue_score, 6),
                                    "distraction_pattern": round(distraction_score, 6),
                                    "face_coverage": round(face_coverage, 6),
                                    "head_state": context["head_state"],
                                    "gaze_state": context["gaze_state"],
                                    "head_away_ratio": round(float(context["head_away_ratio"]), 6),
                                    "gaze_away_ratio": round(float(context["gaze_away_ratio"]), 6),
                                    "motion_state": context["motion_state"],
                                    "motion_score": round(float(context["motion_score"]), 6),
                                    "accel_deviation_m_s2": round(float(context["accel_deviation_m_s2"]), 6),
                                    "rotation_rate_deg_s": round(float(context["rotation_rate_deg_s"]), 6),
                                    "reason": reason,
                                    **features,
                                }
                                windows_writer.writerow(prediction_row)
                                windows_file.flush()
                                predictions.append(prediction_row)
                            else:
                                last_status = "Signal unavailable"
                                last_reason = "Waiting for sufficient face coverage and both IMU streams"

                    current_face_coverage = (
                        sum(sample["face_detected"] for sample in sample_buffer) / max(1, len(sample_buffer))
                        if sample_buffer
                        else (1.0 if face_detected else 0.0)
                    )
                    draw_assessment_overlay(
                        frame,
                        last_status,
                        elapsed,
                        last_caution_probability,
                        current_face_coverage,
                        imu_ready,
                        last_reason,
                        baseline_remaining if not baseline_ready else 0.0,
                        last_context,
                    )

                    if video_writer is not None:
                        video_writer.write(clean_frame)
                    cv2.imshow(WINDOW_TITLE, frame)
                    key = cv2.waitKey(1) & 0xFF
                    if key in (ord("q"), 27):
                        break

    finally:
        ended_at = datetime.now()
        capture.stop()
        if video_writer is not None:
            video_writer.release()
        cv2.destroyAllWindows()
        write_report(report_path, metadata, started_at, ended_at, predictions, video_path, windows_path)
        print("\nAssessment finished.")
        print(f"Text report: {report_path}")
        print(f"Window data: {windows_path}")
        if video_path is not None:
            print(f"MP4 video: {video_path}")


if __name__ == "__main__":
    main()
