DRIVE//STATE — Passive Windows + Intel RealSense D435i assessment
=================================================================

Purpose
-------
This Windows companion assesses naturally occurring driver-state patterns from
the D435i RGB camera, accelerometer and gyroscope. It does not ask the
participant to perform scripted eye closures or head movements. After a short
five-second passive reference period for open-eye level, neutral head/gaze and
the mounted D435i IMU, it scores a rolling two-second window once per second
until the operator presses Q or Esc.

The original prompted data-collection protocol is a separate research tool and
is not launched by this package.

Requirements
------------
- Windows 10 or Windows 11, 64 bit
- Python 3.11 installed with the "py" launcher available
- Intel RealSense D435i connected directly through USB 3
- Intel RealSense Viewer and other camera apps closed before starting
- If using Parallels, pass the complete D435i USB device into Windows

Start
-----
1. Extract the ZIP file completely.
2. Double-click install_and_run.bat.
3. The first run creates a local environment and installs dependencies.
4. Enter the participant/session metadata and choose whether to save MP4.
5. Sit naturally in view. No scripted participant actions are required.
6. Press Q or Esc in the preview window to finish and save the report.

Live output
-----------
- A large current status: Fine, Distracted, Fatigue or Critical
- Random Forest Caution probability
- Head and gaze direction with relative yaw and pitch
- Calibrated vehicle-motion context: Steady, Cornering / movement or Sudden motion
- Acceleration change, rotation rate, face coverage and IMU readiness
- A concise explanation of the dominant pattern

Saved locally
-------------
- data\reports\..._assessment.txt — human-readable session summary
- data\assessment_windows\..._windows.csv — rolling model outputs and features
- data\assessment_video\....mp4 — optional raw video recording

Model boundary
--------------
The packaged Random Forest is the evaluated 87-feature visual-inertial model.
It was trained for two labels: Fine and Caution. Its held-out test accuracy is
86.7%, Caution F1 is 76.8%, and ROC-AUC is 91.6%.

Distracted, Fatigue and Critical are transparent prototype interpretations of
a Caution window. Sustained head or gaze-away evidence supports Distracted;
eye-closure evidence supports Fatigue. Critical is reserved for prolonged
closure, very strong combined driver evidence, or strong driver evidence that
coincides with unusual session-calibrated IMU motion. IMU motion alone never
produces Critical. These three labels are not separately learned four-class
predictions. A future participant-separated four-class dataset is required to
validate them as independent classes.

IMU boundary
------------
The D435i accelerometer and gyroscope are referenced during the first five
seconds. A motion alert can reflect cornering, braking, road vibration, impact
or movement of the camera mount. It is supporting context, not proof of a
pre-crash event, and this prototype is not a crash-prediction system.

Privacy and safety
------------------
Processing and output stay on the Windows computer. Run the prototype with the
operator responsible for safe use. It is a university research aid, not a
medical diagnosis or production-certified vehicle safety system.
