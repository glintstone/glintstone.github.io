import csv
import threading
import time
from datetime import datetime
from pathlib import Path

import cv2
import mediapipe as mp
import numpy as np
import pyrealsense2 as rs


# ============================================================
# Paths
# ============================================================

PROJECT_DIR = Path(__file__).resolve().parent
MODEL_PATH = PROJECT_DIR / "models" / "face_landmarker.task"
CSV_DIR = PROJECT_DIR / "data" / "raw_csv"
VIDEO_DIR = PROJECT_DIR / "data" / "raw_video"
CSV_DIR.mkdir(parents=True, exist_ok=True)
VIDEO_DIR.mkdir(parents=True, exist_ok=True)


# ============================================================
# RealSense RGB + IMU settings for Windows / Parallels
# ============================================================

INPUT_WIDTH = 1280
INPUT_HEIGHT = 720
OUTPUT_WIDTH = 640
OUTPUT_HEIGHT = 360
FPS = 30
WINDOW_TITLE = "RealSense 120-Second Session Recorder"

ACCEL_FPS = 63
GYRO_FPS = 200


# ============================================================
# Face / eye settings
# ============================================================

LEFT_EYE_POINTS = [362, 385, 387, 263, 373, 380]
RIGHT_EYE_POINTS = [33, 160, 158, 133, 153, 144]

OPEN_CALIBRATION_SECONDS = 5.0
CLOSED_CALIBRATION_SECONDS = 2.0
MIN_OPEN_SAMPLES = 30
MIN_CLOSED_SAMPLES = 12
VALID_EAR_MIN = 0.03
VALID_EAR_MAX = 0.80
MIN_OPEN_CLOSED_GAP = 0.05
THRESHOLD_POSITION = 0.50

# Engineering starting values, not medical thresholds.
CLOSED_FRAMES_REQUIRED = 3
MIN_BLINK_DURATION_MS = 100
MAX_BLINK_DURATION_MS = 500

# Head-pose calibration and display smoothing.
MIN_NEUTRAL_HEAD_SAMPLES = 30
HEAD_SMOOTHING_ALPHA = 0.25


# ============================================================
# Exact 120-second protocol
#
# All deliberate eye-closing/head-movement actions must be done
# only in a parked vehicle or simulator.
# ============================================================

PROTOCOL = [
    {
        "duration": 30,
        "activity": "Normal_Baseline",
        "target_state": "Fine",
        "use_for_training": 1,
        "instruction": "Face forward with natural eye behaviour",
    },
    {
        "duration": 5,
        "activity": "Transition_to_Mirror",
        "target_state": "Transition",
        "use_for_training": 0,
        "instruction": "Keep eyes open and prepare for mirror checks",
    },
    {
        "duration": 20,
        "activity": "Mirror_Check",
        "target_state": "Fine",
        "use_for_training": 1,
        "instruction": "Perform natural left and right mirror checks",
    },
    {
        "duration": 5,
        "activity": "Transition_to_SlowBlink",
        "target_state": "Transition",
        "use_for_training": 0,
        "instruction": "Face forward and prepare for the next action",
    },
    {
        "duration": 30,
        "activity": "SlowBlink_HeadMovement",
        "target_state": "Caution",
        "use_for_training": 1,
        "instruction": "Slow blinks with slight, natural head movements",
    },
    {
        "duration": 5,
        "activity": "Transition_to_Recovery",
        "target_state": "Transition",
        "use_for_training": 0,
        "instruction": "Open eyes normally and return to neutral",
    },
    {
        "duration": 25,
        "activity": "Normal_Recovery",
        "target_state": "Fine",
        "use_for_training": 1,
        "instruction": "Face forward with natural eye behaviour",
    },
]

TOTAL_PROTOCOL_SECONDS = sum(int(item["duration"]) for item in PROTOCOL)


# ============================================================
# Metadata
# ============================================================

def normalize_id(value: str, prefix: str, width: int) -> str:
    value = value.strip().upper()

    if value.isdigit():
        return f"{prefix}{int(value):0{width}d}"

    if value.startswith(prefix) and value[len(prefix):].isdigit():
        number = int(value[len(prefix):])
        return f"{prefix}{number:0{width}d}"

    cleaned = "".join(
        ch for ch in value if ch.isalnum() or ch in {"-", "_"}
    )
    if not cleaned:
        raise ValueError(f"{prefix} ID cannot be empty.")
    return cleaned


def ask_vehicle_type() -> str:
    choices = {
        "1": "Sedan",
        "2": "Hatchback",
        "3": "MPV",
        "4": "SUV",
        "5": "Other",
    }

    print("\nVehicle type")
    for key, value in choices.items():
        print(f"{key} = {value}")

    while True:
        choice = input("Select vehicle type: ").strip()
        if choice in choices:
            return choices[choice]
        print("Enter a number from 1 to 5.")

def collect_metadata() -> dict[str, str]:
    print("\n======================================")
    print("Controlled Session Metadata")
    print("======================================")

    participant_id = normalize_id(
        input("Participant, Personnel ID, P1: "), "P", 2
    )
    session_id = normalize_id(
        input("Session ID, S1, S2, S3 etc. : "), "S", 3
    )
    vehicle_type = ask_vehicle_type()
    vehicle_model = input(
        "Vehicle model: "
    ).strip() or "Not_Specified"

    environment_input = input(
        "Environment (Parked?): "
    ).strip().lower()

    if environment_input not in {
        "parked",
        "parked vehicle",
        "simulator",
    }:
        raise RuntimeError(
            "Session cancelled. Use only a parked vehicle or simulator."
        )

    print(
        "\nSAFETY: This protocol contains deliberate slow eye closures "
        "and head movements."
    )
    confirmation = input(
        'Type "SAFE" to start: '
    ).strip().upper()

    if confirmation != "SAFE":
        raise RuntimeError("Session cancelled: safety was not confirmed.")

    environment = (
        "Simulator"
        if environment_input == "simulator"
        else "Parked_Vehicle"
    )

    return {
        "participant_id": participant_id,
        "session_id": session_id,
        "vehicle_type": vehicle_type,
        "vehicle_model": vehicle_model,
        "environment": environment,
    }


# ============================================================
# Camera, protocol and video helpers
# ============================================================

class RealSenseAsyncCapture:
    """Receive RGB and motion frames independently.

    A RealSense pipeline waits for a synchronized composite frameset. Some
    virtualized USB stacks can deliver every D435i stream but never assemble
    that composite, which produces ``Frame didn't arrive within 5000``. Direct
    sensor callbacks avoid that synchronization gate while preserving each
    device timestamp. Each RGB row uses the newest accelerometer and gyroscope
    sample available when the RGB frame arrives.
    """

    def __init__(self) -> None:
        self.context = rs.context()
        devices = self.context.query_devices()

        if len(devices) == 0:
            raise RuntimeError(
                "No RealSense device detected. Close RealSense Viewer and "
                "connect the D435i directly to Windows through USB 3."
            )

        self.device = devices[0]
        self.condition = threading.Condition()
        self.color_sequence = 0
        self.latest_color: np.ndarray | None = None
        self.latest_color_timestamp_ms: float | None = None
        self.latest_accel: tuple[float, float, float] | None = None
        self.latest_accel_timestamp_ms: float | None = None
        self.latest_gyro: tuple[float, float, float] | None = None
        self.latest_gyro_timestamp_ms: float | None = None
        self.callback_error: str | None = None
        self.color_format = rs.format.bgr8
        self.opened_sensors: list[rs.sensor] = []
        self.started_sensors: list[rs.sensor] = []

    @staticmethod
    def _choose_motion_profile(
        candidates: list[tuple[rs.sensor, rs.stream_profile]],
        target_fps: int,
        stream_name: str,
    ) -> tuple[rs.sensor, rs.stream_profile]:
        if not candidates:
            raise RuntimeError(
                f"The D435i {stream_name} stream is unavailable. "
                "Confirm that Motion Module works in RealSense Viewer."
            )

        return min(
            candidates,
            key=lambda candidate: abs(candidate[1].fps() - target_fps),
        )

    @staticmethod
    def _color_score(profile: rs.stream_profile) -> tuple[int, int, int]:
        video = profile.as_video_stream_profile()
        format_order = {
            rs.format.bgr8: 0,
            rs.format.rgb8: 1,
            rs.format.yuyv: 2,
        }
        size_order = {
            (INPUT_WIDTH, INPUT_HEIGHT): 0,
            (640, 480): 1,
        }
        return (
            abs(profile.fps() - FPS),
            size_order.get((video.width(), video.height()), 2),
            format_order.get(profile.format(), 3),
        )

    def _select_profiles(
        self,
    ) -> tuple[
        rs.sensor,
        rs.stream_profile,
        rs.sensor,
        rs.stream_profile,
        rs.stream_profile,
    ]:
        color_candidates: list[tuple[rs.sensor, rs.stream_profile]] = []
        accel_candidates: list[tuple[rs.sensor, rs.stream_profile]] = []
        gyro_candidates: list[tuple[rs.sensor, rs.stream_profile]] = []
        supported_color_formats = {
            rs.format.bgr8,
            rs.format.rgb8,
            rs.format.yuyv,
        }

        for sensor in self.device.query_sensors():
            for profile in sensor.get_stream_profiles():
                stream_type = profile.stream_type()
                if (
                    stream_type == rs.stream.color
                    and profile.format() in supported_color_formats
                ):
                    color_candidates.append((sensor, profile))
                elif (
                    stream_type == rs.stream.accel
                    and profile.format() == rs.format.motion_xyz32f
                ):
                    accel_candidates.append((sensor, profile))
                elif (
                    stream_type == rs.stream.gyro
                    and profile.format() == rs.format.motion_xyz32f
                ):
                    gyro_candidates.append((sensor, profile))

        if not color_candidates:
            raise RuntimeError(
                "The D435i RGB stream is unavailable. Close every camera app "
                "and confirm RGB works in RealSense Viewer."
            )

        color_sensor, color_profile = min(
            color_candidates,
            key=lambda candidate: self._color_score(candidate[1]),
        )
        accel_sensor, accel_profile = self._choose_motion_profile(
            accel_candidates,
            ACCEL_FPS,
            "accelerometer",
        )
        gyro_sensor, gyro_profile = self._choose_motion_profile(
            gyro_candidates,
            GYRO_FPS,
            "gyroscope",
        )

        if accel_sensor != gyro_sensor:
            raise RuntimeError(
                "Accelerometer and gyroscope were exposed on different "
                "motion sensors; this collector requires one D435i device."
            )

        return (
            color_sensor,
            color_profile,
            accel_sensor,
            accel_profile,
            gyro_profile,
        )

    def _record_callback_error(self, error: Exception) -> None:
        with self.condition:
            self.callback_error = f"{type(error).__name__}: {error}"
            self.condition.notify_all()

    def _on_color_frame(self, frame: rs.frame) -> None:
        try:
            image = np.asanyarray(frame.get_data()).copy()
            if self.color_format == rs.format.rgb8:
                image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
            elif self.color_format == rs.format.yuyv:
                image = cv2.cvtColor(image, cv2.COLOR_YUV2BGR_YUY2)

            with self.condition:
                self.latest_color = image
                self.latest_color_timestamp_ms = float(
                    frame.get_timestamp()
                )
                self.color_sequence += 1
                self.condition.notify_all()
        except Exception as error:
            self._record_callback_error(error)

    def _on_motion_frame(self, frame: rs.frame) -> None:
        try:
            stream_type = frame.get_profile().stream_type()
            motion = frame.as_motion_frame().get_motion_data()
            values = (
                float(motion.x),
                float(motion.y),
                float(motion.z),
            )
            timestamp_ms = float(frame.get_timestamp())

            with self.condition:
                if stream_type == rs.stream.accel:
                    self.latest_accel = values
                    self.latest_accel_timestamp_ms = timestamp_ms
                elif stream_type == rs.stream.gyro:
                    self.latest_gyro = values
                    self.latest_gyro_timestamp_ms = timestamp_ms
                self.condition.notify_all()
        except Exception as error:
            self._record_callback_error(error)

    def start(self) -> None:
        (
            color_sensor,
            color_profile,
            motion_sensor,
            accel_profile,
            gyro_profile,
        ) = self._select_profiles()

        color_video = color_profile.as_video_stream_profile()
        self.color_format = color_profile.format()

        try:
            color_sensor.open(color_profile)
            self.opened_sensors.append(color_sensor)
            motion_sensor.open([accel_profile, gyro_profile])
            self.opened_sensors.append(motion_sensor)

            color_sensor.start(self._on_color_frame)
            self.started_sensors.append(color_sensor)
            motion_sensor.start(self._on_motion_frame)
            self.started_sensors.append(motion_sensor)
        except Exception:
            self.stop()
            raise

        print(
            "RealSense device:",
            self.device.get_info(rs.camera_info.name),
        )
        print(
            "Firmware:",
            self.device.get_info(rs.camera_info.firmware_version),
        )
        print(
            "RGB profile:",
            f"{color_video.width()}x{color_video.height()} @ "
            f"{color_profile.fps()} FPS ({color_profile.format()})",
        )
        print(
            "IMU profiles:",
            f"accelerometer {accel_profile.fps()} Hz, "
            f"gyroscope {gyro_profile.fps()} Hz",
        )

    def wait_for_color(
        self,
        after_sequence: int,
        timeout_seconds: float = 10.0,
    ) -> tuple[
        int,
        np.ndarray,
        float,
        tuple[float, float, float] | None,
        float | None,
        tuple[float, float, float] | None,
        float | None,
    ]:
        deadline = time.monotonic() + timeout_seconds
        with self.condition:
            while self.color_sequence <= after_sequence:
                if self.callback_error is not None:
                    raise RuntimeError(
                        "A RealSense callback failed: "
                        f"{self.callback_error}"
                    )
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise RuntimeError(
                        "The RGB stream stopped delivering frames for "
                        f"{timeout_seconds:.0f} seconds. Close other camera "
                        "apps and reconnect the D435i through USB 3."
                    )
                self.condition.wait(remaining)

            if (
                self.latest_color is None
                or self.latest_color_timestamp_ms is None
            ):
                raise RuntimeError("RGB callback state is incomplete.")

            return (
                self.color_sequence,
                self.latest_color.copy(),
                self.latest_color_timestamp_ms,
                self.latest_accel,
                self.latest_accel_timestamp_ms,
                self.latest_gyro,
                self.latest_gyro_timestamp_ms,
            )

    def poll_color(self, after_sequence: int):
        """Return a new RGB packet immediately, or None if none is ready."""
        with self.condition:
            if self.callback_error is not None:
                raise RuntimeError(
                    "A RealSense callback failed: "
                    f"{self.callback_error}"
                )
            if self.color_sequence <= after_sequence:
                return None
            if (
                self.latest_color is None
                or self.latest_color_timestamp_ms is None
            ):
                raise RuntimeError("RGB callback state is incomplete.")

            return (
                self.color_sequence,
                self.latest_color.copy(),
                self.latest_color_timestamp_ms,
                self.latest_accel,
                self.latest_accel_timestamp_ms,
                self.latest_gyro,
                self.latest_gyro_timestamp_ms,
            )

    def stop(self) -> None:
        for sensor in reversed(self.started_sensors):
            try:
                sensor.stop()
            except Exception as error:
                print(f"RealSense sensor stop warning: {error}")
        self.started_sensors.clear()

        for sensor in reversed(self.opened_sensors):
            try:
                sensor.close()
            except Exception as error:
                print(f"RealSense sensor close warning: {error}")
        self.opened_sensors.clear()


def create_realsense_capture() -> RealSenseAsyncCapture:
    capture = RealSenseAsyncCapture()
    try:
        capture.start()
    except Exception:
        capture.stop()
        raise
    print("RealSense sensors opened. Launching the preview window...")
    return capture

def create_video_writer(path: Path) -> cv2.VideoWriter:
    codec = cv2.VideoWriter_fourcc(*"mp4v")
    writer = cv2.VideoWriter(
        str(path),
        codec,
        FPS,
        (OUTPUT_WIDTH, OUTPUT_HEIGHT),
    )
    if not writer.isOpened():
        raise RuntimeError("OpenCV could not create the MP4 recording.")
    return writer


def get_protocol_segment(
    elapsed_seconds: float,
) -> tuple[dict[str, object] | None, float]:
    start = 0.0

    for segment in PROTOCOL:
        end = start + float(segment["duration"])
        if start <= elapsed_seconds < end:
            return segment, end - elapsed_seconds
        start = end

    return None, 0.0


# ============================================================
# EAR calculations and drawing
# ============================================================

def get_point(landmarks, index: int) -> np.ndarray:
    point = landmarks[index]
    return np.array([point.x, point.y], dtype=np.float64)


def calculate_ear(landmarks, indexes: list[int]) -> float:
    p1, p2, p3, p4, p5, p6 = (
        get_point(landmarks, index) for index in indexes
    )

    vertical_1 = np.linalg.norm(p2 - p6)
    vertical_2 = np.linalg.norm(p3 - p5)
    horizontal = np.linalg.norm(p1 - p4)

    if horizontal == 0:
        return 0.0

    return float((vertical_1 + vertical_2) / (2.0 * horizontal))


def draw_eye_points(
    frame: np.ndarray,
    landmarks,
    indexes: list[int],
) -> None:
    height, width = frame.shape[:2]

    for index in indexes:
        point = landmarks[index]
        x = int(point.x * width)
        y = int(point.y * height)

        if 0 <= x < width and 0 <= y < height:
            cv2.circle(
                frame,
                (x, y),
                3,
                (0, 255, 255),
                -1,
                cv2.LINE_AA,
            )


def put_text(
    frame: np.ndarray,
    text: str,
    y: int,
    colour: tuple[int, int, int] = (255, 255, 255),
    scale: float = 0.55,
    thickness: int = 2,
) -> None:
    cv2.putText(
        frame,
        text,
        (20, y),
        cv2.FONT_HERSHEY_SIMPLEX,
        scale,
        colour,
        thickness,
        cv2.LINE_AA,
    )


# ============================================================
# Head-pose calculations
# ============================================================

def normalise_rotation_matrix(matrix: np.ndarray) -> np.ndarray:
    """Return the nearest proper 3x3 rotation matrix."""
    rotation_like = np.asarray(matrix, dtype=np.float64)[:3, :3]
    u, _, vt = np.linalg.svd(rotation_like)
    rotation = u @ vt

    if np.linalg.det(rotation) < 0:
        u[:, -1] *= -1
        rotation = u @ vt

    return rotation


def rotation_matrix_to_euler_degrees(
    rotation: np.ndarray,
) -> tuple[float, float, float]:
    """Return pitch, yaw and roll in degrees."""
    sy = float(
        np.sqrt(rotation[0, 0] ** 2 + rotation[1, 0] ** 2)
    )
    singular = sy < 1e-6

    if not singular:
        pitch = np.arctan2(rotation[2, 1], rotation[2, 2])
        yaw = np.arctan2(-rotation[2, 0], sy)
        roll = np.arctan2(rotation[1, 0], rotation[0, 0])
    else:
        pitch = np.arctan2(-rotation[1, 2], rotation[1, 1])
        yaw = np.arctan2(-rotation[2, 0], sy)
        roll = 0.0

    return tuple(
        float(np.degrees(value))
        for value in (pitch, yaw, roll)
    )


def extract_head_pose(
    transformation_matrix: np.ndarray,
) -> tuple[float, float, float]:
    rotation = normalise_rotation_matrix(transformation_matrix)
    return rotation_matrix_to_euler_degrees(rotation)


def wrapped_angle_difference(value: float, baseline: float) -> float:
    """Subtract two angles and keep the result within -180 to 180."""
    return float((value - baseline + 180.0) % 360.0 - 180.0)


def smooth_head_angle(
    previous: float | None,
    current: float,
) -> float:
    if previous is None:
        return current

    return (
        (1.0 - HEAD_SMOOTHING_ALPHA) * previous
        + HEAD_SMOOTHING_ALPHA * current
    )


# ============================================================
# Blink / prolonged closure tracker
# ============================================================

class EyeEventTracker:
    def __init__(self) -> None:
        self.candidate_frames = 0
        self.candidate_start_ms: int | None = None
        self.closure_active = False
        self.closure_start_ms: int | None = None

        self.blink_count = 0
        self.prolonged_count = 0
        self.current_duration_ms = 0
        self.last_duration_ms = 0

    def reset_active_event(self) -> None:
        self.candidate_frames = 0
        self.candidate_start_ms = None
        self.closure_active = False
        self.closure_start_ms = None
        self.current_duration_ms = 0

    def reset_all(self) -> None:
        self.reset_active_event()
        self.blink_count = 0
        self.prolonged_count = 0
        self.last_duration_ms = 0

    def update(
        self,
        face_detected: bool,
        average_ear: float | None,
        ear_threshold: float,
        timestamp_ms: int,
    ) -> dict[str, object]:
        event = ""
        below_threshold = False
        eyes_closed = False

        if not face_detected or average_ear is None:
            if self.closure_active or self.candidate_frames > 0:
                event = "Invalidated_Tracking_Loss"
            self.reset_active_event()
            return {
                "ear_below_threshold": False,
                "eyes_closed": False,
                "closure_event": event,
            }

        below_threshold = average_ear < ear_threshold

        if below_threshold:
            if self.candidate_frames == 0:
                self.candidate_start_ms = timestamp_ms

            self.candidate_frames += 1

            if (
                not self.closure_active
                and self.candidate_frames >= CLOSED_FRAMES_REQUIRED
            ):
                self.closure_active = True
                self.closure_start_ms = (
                    self.candidate_start_ms
                    if self.candidate_start_ms is not None
                    else timestamp_ms
                )

            if self.closure_active and self.closure_start_ms is not None:
                eyes_closed = True
                self.current_duration_ms = max(
                    0, timestamp_ms - self.closure_start_ms
                )

        else:
            if self.closure_active and self.closure_start_ms is not None:
                duration = max(0, timestamp_ms - self.closure_start_ms)
                self.last_duration_ms = duration

                if MIN_BLINK_DURATION_MS <= duration <= MAX_BLINK_DURATION_MS:
                    self.blink_count += 1
                    event = "Blink"
                elif duration > MAX_BLINK_DURATION_MS:
                    self.prolonged_count += 1
                    event = "Prolonged_Closure"
                else:
                    event = "Ignored_Too_Short"

            self.reset_active_event()

        return {
            "ear_below_threshold": below_threshold,
            "eyes_closed": eyes_closed,
            "closure_event": event,
        }


# ============================================================
# Main program
# ============================================================

def main() -> None:
    if not MODEL_PATH.exists():
        raise FileNotFoundError(f"Face model not found: {MODEL_PATH}")

    if TOTAL_PROTOCOL_SECONDS != 120:
        raise RuntimeError(
            f"Protocol must equal 120 seconds, not "
            f"{TOTAL_PROTOCOL_SECONDS}."
        )

    metadata = collect_metadata()
    date_code = datetime.now().strftime("%Y%m%d_%H%M%S")
    prefix = (
        f"{metadata['session_id']}_"
        f"{metadata['participant_id']}_"
        f"{date_code}"
    )

    csv_path = CSV_DIR / f"{prefix}.csv"
    video_path = VIDEO_DIR / f"{prefix}.mp4"

    print("\nOutput files")
    print(f"CSV:   {csv_path}")
    print(f"Video: {video_path}")

    options = mp.tasks.vision.FaceLandmarkerOptions(
        base_options=mp.tasks.BaseOptions(
            model_asset_path=str(MODEL_PATH)
        ),
        running_mode=mp.tasks.vision.RunningMode.VIDEO,
        num_faces=1,
        min_face_detection_confidence=0.5,
        min_face_presence_confidence=0.5,
        min_tracking_confidence=0.5,
        output_face_blendshapes=False,
        output_facial_transformation_matrixes=True,
    )

    capture = create_realsense_capture()
    color_sequence = 0
    imu_ready_announced = False

    # MediaPipe timestamp state
    program_start = time.monotonic()
    previous_timestamp_ms = -1

    # Latest IMU values are attached to each 30 FPS RGB row.
    latest_accel: tuple[float, float, float] | None = None
    latest_gyro: tuple[float, float, float] | None = None
    latest_accel_timestamp_ms: float | None = None
    latest_gyro_timestamp_ms: float | None = None

    # Calibration: OPEN -> WAIT_CLOSED -> CLOSED -> DONE
    calibration_stage = "OPEN"
    calibration_start = time.monotonic()
    open_values: list[float] = []
    closed_values: list[float] = []

    # The open-eye stage also calibrates the participant's neutral
    # forward-facing head pose.
    neutral_pitch_values: list[float] = []
    neutral_yaw_values: list[float] = []
    neutral_roll_values: list[float] = []

    neutral_head_pitch = 0.0
    neutral_head_yaw = 0.0
    neutral_head_roll = 0.0

    smoothed_head_pitch: float | None = None
    smoothed_head_yaw: float | None = None
    smoothed_head_roll: float | None = None

    open_baseline = 0.0
    closed_baseline = 0.0
    ear_threshold = 0.0
    calibrated = False

    # Recording state
    session_started = False
    session_completed = False
    session_start = 0.0
    frame_index = 0
    last_segment = ""

    tracker = EyeEventTracker()

    csv_file = None
    csv_writer = None
    video_writer = None

    fieldnames = [
        "session_id",
        "participant_id",
        "vehicle_type",
        "vehicle_model",
        "environment",
        "recorded_at",
        "frame_index",
        "timestamp_ms",
        "realsense_color_timestamp_ms",
        "accel_timestamp_ms",
        "accel_x_m_s2",
        "accel_y_m_s2",
        "accel_z_m_s2",
        "accel_magnitude_m_s2",
        "gyro_timestamp_ms",
        "gyro_x_rad_s",
        "gyro_y_rad_s",
        "gyro_z_rad_s",
        "gyro_magnitude_rad_s",
        "session_elapsed_s",
        "activity_label",
        "target_state",
        "use_for_training",
        "face_detected",
        "head_pose_detected",
        "head_pitch_deg",
        "head_yaw_deg",
        "head_roll_deg",
        "head_movement_magnitude_deg",
        "neutral_head_pitch_deg",
        "neutral_head_yaw_deg",
        "neutral_head_roll_deg",
        "left_ear",
        "right_ear",
        "average_ear",
        "normalized_ear",
        "open_eye_baseline",
        "closed_eye_baseline",
        "ear_threshold",
        "ear_below_threshold",
        "eyes_closed",
        "current_closure_duration_ms",
        "last_closure_duration_ms",
        "closure_event",
        "blink_count",
        "prolonged_closure_count",
    ]

    print("\nRealSense RGB + IMU opened.")
    print("1. Keep eyes naturally open for Stage 1.")
    print("2. Press C when asked, then gently close both eyes.")
    print("3. Open your eyes and press S to start the session.")
    print("R = recalibrate | Q = exit")

    try:
        cv2.namedWindow(WINDOW_TITLE, cv2.WINDOW_NORMAL)
        cv2.resizeWindow(
            WINDOW_TITLE,
            OUTPUT_WIDTH + OUTPUT_WIDTH // 2,
            OUTPUT_HEIGHT + OUTPUT_HEIGHT // 2,
        )
        cv2.moveWindow(WINDOW_TITLE, 60, 60)
        topmost_property = getattr(cv2, "WND_PROP_TOPMOST", None)
        if topmost_property is not None:
            cv2.setWindowProperty(WINDOW_TITLE, topmost_property, 1)

        waiting_frame = np.zeros(
            (OUTPUT_HEIGHT, OUTPUT_WIDTH, 3),
            dtype=np.uint8,
        )
        put_text(
            waiting_frame,
            "D435i CONNECTED",
            145,
            (0, 255, 0),
            0.85,
        )
        put_text(
            waiting_frame,
            "Waiting for the first RGB frame...",
            195,
            (255, 255, 255),
            0.62,
        )
        put_text(
            waiting_frame,
            "IMU readiness will appear in the top-right corner.",
            235,
            (0, 200, 255),
            0.45,
            1,
        )
        cv2.imshow(WINDOW_TITLE, waiting_frame)
        cv2.waitKey(1)

        first_color_packet = None
        first_color_deadline = time.monotonic() + 20.0
        while first_color_packet is None:
            first_color_packet = capture.poll_color(color_sequence)
            if first_color_packet is not None:
                break
            if time.monotonic() >= first_color_deadline:
                raise RuntimeError(
                    "The D435i opened but RGB did not deliver a frame within "
                    "20 seconds. Close RealSense Viewer and every other "
                    "camera app, then reconnect the D435i through USB 3."
                )
            waiting_key = cv2.waitKey(30) & 0xFF
            if waiting_key == ord("q") or waiting_key == 27:
                print("\nSession stopped while waiting for RGB.")
                return

        with mp.tasks.vision.FaceLandmarker.create_from_options(
            options
        ) as landmarker:

            while True:
                if first_color_packet is not None:
                    (
                        color_sequence,
                        full_frame,
                        realsense_color_timestamp_ms,
                        latest_accel,
                        latest_accel_timestamp_ms,
                        latest_gyro,
                        latest_gyro_timestamp_ms,
                    ) = first_color_packet
                    first_color_packet = None
                else:
                    (
                        color_sequence,
                        full_frame,
                        realsense_color_timestamp_ms,
                        latest_accel,
                        latest_accel_timestamp_ms,
                        latest_gyro,
                        latest_gyro_timestamp_ms,
                    ) = capture.wait_for_color(
                        color_sequence,
                        timeout_seconds=10.0,
                    )

                clean_frame = cv2.resize(
                    full_frame,
                    (OUTPUT_WIDTH, OUTPUT_HEIGHT),
                    interpolation=cv2.INTER_AREA,
                )
                display_frame = clean_frame.copy()

                rgb_frame = cv2.cvtColor(clean_frame, cv2.COLOR_BGR2RGB)
                mp_image = mp.Image(
                    image_format=mp.ImageFormat.SRGB,
                    data=rgb_frame,
                )

                timestamp_ms = int(
                    (time.monotonic() - program_start) * 1000
                )
                timestamp_ms = max(
                    timestamp_ms,
                    previous_timestamp_ms + 1,
                )
                previous_timestamp_ms = timestamp_ms

                result = landmarker.detect_for_video(
                    mp_image,
                    timestamp_ms,
                )

                face_detected = bool(result.face_landmarks)
                matrices = getattr(
                    result,
                    "facial_transformation_matrixes",
                    [],
                )
                head_pose_detected = bool(face_detected and matrices)

                raw_head_pitch: float | None = None
                raw_head_yaw: float | None = None
                raw_head_roll: float | None = None

                head_pitch: float | None = None
                head_yaw: float | None = None
                head_roll: float | None = None
                head_movement_magnitude: float | None = None

                if head_pose_detected:
                    (
                        raw_head_pitch,
                        raw_head_yaw,
                        raw_head_roll,
                    ) = extract_head_pose(matrices[0])

                    if calibrated:
                        relative_pitch = wrapped_angle_difference(
                            raw_head_pitch,
                            neutral_head_pitch,
                        )
                        relative_yaw = wrapped_angle_difference(
                            raw_head_yaw,
                            neutral_head_yaw,
                        )
                        relative_roll = wrapped_angle_difference(
                            raw_head_roll,
                            neutral_head_roll,
                        )

                        smoothed_head_pitch = smooth_head_angle(
                            smoothed_head_pitch,
                            relative_pitch,
                        )
                        smoothed_head_yaw = smooth_head_angle(
                            smoothed_head_yaw,
                            relative_yaw,
                        )
                        smoothed_head_roll = smooth_head_angle(
                            smoothed_head_roll,
                            relative_roll,
                        )

                        head_pitch = smoothed_head_pitch
                        head_yaw = smoothed_head_yaw
                        head_roll = smoothed_head_roll
                        head_movement_magnitude = float(
                            np.linalg.norm(
                                [head_pitch, head_yaw, head_roll]
                            )
                        )
                else:
                    # Do not carry stale pose values through tracking loss.
                    smoothed_head_pitch = None
                    smoothed_head_yaw = None
                    smoothed_head_roll = None

                left_ear: float | None = None
                right_ear: float | None = None
                average_ear: float | None = None
                normalized_ear: float | None = None

                if face_detected:
                    landmarks = result.face_landmarks[0]
                    draw_eye_points(
                        display_frame,
                        landmarks,
                        LEFT_EYE_POINTS,
                    )
                    draw_eye_points(
                        display_frame,
                        landmarks,
                        RIGHT_EYE_POINTS,
                    )

                    left_ear = calculate_ear(
                        landmarks,
                        LEFT_EYE_POINTS,
                    )
                    right_ear = calculate_ear(
                        landmarks,
                        RIGHT_EYE_POINTS,
                    )
                    average_ear = (left_ear + right_ear) / 2.0

                    if open_baseline > 0:
                        normalized_ear = average_ear / open_baseline

                # -------------------- Calibration --------------------

                if not session_started and calibration_stage == "OPEN":
                    elapsed = time.monotonic() - calibration_start
                    remaining = max(
                        0.0,
                        OPEN_CALIBRATION_SECONDS - elapsed,
                    )

                    if (
                        average_ear is not None
                        and VALID_EAR_MIN < average_ear < VALID_EAR_MAX
                    ):
                        open_values.append(average_ear)

                    if (
                        raw_head_pitch is not None
                        and raw_head_yaw is not None
                        and raw_head_roll is not None
                    ):
                        neutral_pitch_values.append(raw_head_pitch)
                        neutral_yaw_values.append(raw_head_yaw)
                        neutral_roll_values.append(raw_head_roll)

                    put_text(
                        display_frame,
                        "STAGE 1: KEEP EYES NATURALLY OPEN",
                        35,
                        (0, 255, 255),
                        0.66,
                    )
                    put_text(
                        display_frame,
                        f"Remaining: {remaining:.1f}s",
                        70,
                    )

                    if average_ear is not None:
                        put_text(
                            display_frame,
                            f"Current EAR: {average_ear:.3f}",
                            105,
                        )

                    if elapsed >= OPEN_CALIBRATION_SECONDS:
                        if (
                            len(open_values) < MIN_OPEN_SAMPLES
                            or len(neutral_yaw_values)
                            < MIN_NEUTRAL_HEAD_SAMPLES
                        ):
                            print(
                                "Open/head calibration restarted: "
                                "not enough valid face samples."
                            )
                            open_values.clear()
                            neutral_pitch_values.clear()
                            neutral_yaw_values.clear()
                            neutral_roll_values.clear()
                            calibration_start = time.monotonic()
                        else:
                            open_baseline = float(np.median(open_values))
                            neutral_head_pitch = float(
                                np.median(neutral_pitch_values)
                            )
                            neutral_head_yaw = float(
                                np.median(neutral_yaw_values)
                            )
                            neutral_head_roll = float(
                                np.median(neutral_roll_values)
                            )
                            calibration_stage = "WAIT_CLOSED"
                            print(
                                f"\nOpen-eye baseline: {open_baseline:.3f}"
                            )
                            print(
                                "Neutral head pose: "
                                f"pitch={neutral_head_pitch:.2f}, "
                                f"yaw={neutral_head_yaw:.2f}, "
                                f"roll={neutral_head_roll:.2f}"
                            )
                            print(
                                "Press C in the video window, "
                                "then gently close both eyes."
                            )

                elif (
                    not session_started
                    and calibration_stage == "WAIT_CLOSED"
                ):
                    put_text(
                        display_frame,
                        "STAGE 1 COMPLETE",
                        35,
                        (0, 255, 0),
                        0.72,
                    )
                    put_text(
                        display_frame,
                        f"Open baseline: {open_baseline:.3f}",
                        70,
                    )
                    put_text(
                        display_frame,
                        "Press C, then gently close both eyes",
                        105,
                        (0, 255, 255),
                    )

                elif (
                    not session_started
                    and calibration_stage == "CLOSED"
                ):
                    elapsed = time.monotonic() - calibration_start
                    remaining = max(
                        0.0,
                        CLOSED_CALIBRATION_SECONDS - elapsed,
                    )

                    if (
                        average_ear is not None
                        and VALID_EAR_MIN < average_ear < VALID_EAR_MAX
                    ):
                        closed_values.append(average_ear)

                    put_text(
                        display_frame,
                        "STAGE 2: KEEP BOTH EYES GENTLY CLOSED",
                        35,
                        (0, 255, 255),
                        0.62,
                    )
                    put_text(
                        display_frame,
                        f"Remaining: {remaining:.1f}s",
                        70,
                    )

                    if average_ear is not None:
                        put_text(
                            display_frame,
                            f"Current EAR: {average_ear:.3f}",
                            105,
                        )

                    if elapsed >= CLOSED_CALIBRATION_SECONDS:
                        if len(closed_values) < MIN_CLOSED_SAMPLES:
                            print(
                                "Closed calibration failed: "
                                "not enough valid frames."
                            )
                            closed_values.clear()
                            calibration_stage = "WAIT_CLOSED"
                        else:
                            closed_baseline = float(
                                np.median(closed_values)
                            )
                            gap = open_baseline - closed_baseline

                            if gap < MIN_OPEN_CLOSED_GAP:
                                print(
                                    "\nCalibration rejected: open and "
                                    "closed EAR values were too similar."
                                )
                                print(
                                    "Restarting. Improve lighting and "
                                    "keep the full face visible."
                                )
                                calibration_stage = "OPEN"
                                calibration_start = time.monotonic()
                                open_values.clear()
                                closed_values.clear()
                                neutral_pitch_values.clear()
                                neutral_yaw_values.clear()
                                neutral_roll_values.clear()
                                neutral_head_pitch = 0.0
                                neutral_head_yaw = 0.0
                                neutral_head_roll = 0.0
                                smoothed_head_pitch = None
                                smoothed_head_yaw = None
                                smoothed_head_roll = None
                                open_baseline = 0.0
                                closed_baseline = 0.0
                                ear_threshold = 0.0
                            else:
                                ear_threshold = (
                                    closed_baseline
                                    + THRESHOLD_POSITION * gap
                                )
                                calibrated = True
                                calibration_stage = "DONE"

                                print("\nCalibration completed.")
                                print(
                                    f"Open baseline:   {open_baseline:.3f}"
                                )
                                print(
                                    f"Closed baseline: {closed_baseline:.3f}"
                                )
                                print(
                                    f"EAR threshold:   {ear_threshold:.3f}"
                                )
                                print(
                                    "Open eyes normally and press S."
                                )

                elif (
                    not session_started
                    and calibration_stage == "DONE"
                ):
                    put_text(
                        display_frame,
                        "CALIBRATION COMPLETE",
                        35,
                        (0, 255, 0),
                        0.72,
                    )
                    put_text(
                        display_frame,
                        f"Open: {open_baseline:.3f} | "
                        f"Closed: {closed_baseline:.3f}",
                        70,
                    )
                    put_text(
                        display_frame,
                        f"Threshold: {ear_threshold:.3f}",
                        105,
                    )
                    put_text(
                        display_frame,
                        "OPEN EYES NORMALLY - PRESS S TO START",
                        140,
                        (0, 255, 255),
                        0.57,
                    )

                # -------------------- Recording --------------------

                if session_started:
                    eye_state = tracker.update(
                        face_detected=face_detected,
                        average_ear=average_ear,
                        ear_threshold=ear_threshold,
                        timestamp_ms=timestamp_ms,
                    )

                    session_elapsed = time.monotonic() - session_start
                    segment, segment_remaining = get_protocol_segment(
                        session_elapsed
                    )

                    if segment is None:
                        session_completed = True
                        print("\n120-second protocol completed.")
                        break

                    activity = str(segment["activity"])
                    target_state = str(segment["target_state"])
                    use_for_training = int(segment["use_for_training"])
                    instruction = str(segment["instruction"])

                    if activity != last_segment:
                        last_segment = activity
                        print(
                            f"\nSegment: {activity} "
                            f"({int(segment['duration'])} seconds)"
                        )
                        print(f"Instruction: {instruction}")

                    if video_writer is not None:
                        video_writer.write(clean_frame)

                    accel_x = accel_y = accel_z = None
                    accel_magnitude = None
                    if latest_accel is not None:
                        accel_x, accel_y, accel_z = latest_accel
                        accel_magnitude = float(
                            np.linalg.norm(latest_accel)
                        )

                    gyro_x = gyro_y = gyro_z = None
                    gyro_magnitude = None
                    if latest_gyro is not None:
                        gyro_x, gyro_y, gyro_z = latest_gyro
                        gyro_magnitude = float(
                            np.linalg.norm(latest_gyro)
                        )

                    row = {
                        "session_id": metadata["session_id"],
                        "participant_id": metadata["participant_id"],
                        "vehicle_type": metadata["vehicle_type"],
                        "vehicle_model": metadata["vehicle_model"],
                        "environment": metadata["environment"],
                        "recorded_at": datetime.now().isoformat(
                            timespec="milliseconds"
                        ),
                        "frame_index": frame_index,
                        "timestamp_ms": timestamp_ms,
                        "realsense_color_timestamp_ms": round(
                            realsense_color_timestamp_ms, 3
                        ),
                        "accel_timestamp_ms": (
                            round(latest_accel_timestamp_ms, 3)
                            if latest_accel_timestamp_ms is not None
                            else ""
                        ),
                        "accel_x_m_s2": (
                            round(accel_x, 6)
                            if accel_x is not None
                            else ""
                        ),
                        "accel_y_m_s2": (
                            round(accel_y, 6)
                            if accel_y is not None
                            else ""
                        ),
                        "accel_z_m_s2": (
                            round(accel_z, 6)
                            if accel_z is not None
                            else ""
                        ),
                        "accel_magnitude_m_s2": (
                            round(accel_magnitude, 6)
                            if accel_magnitude is not None
                            else ""
                        ),
                        "gyro_timestamp_ms": (
                            round(latest_gyro_timestamp_ms, 3)
                            if latest_gyro_timestamp_ms is not None
                            else ""
                        ),
                        "gyro_x_rad_s": (
                            round(gyro_x, 6)
                            if gyro_x is not None
                            else ""
                        ),
                        "gyro_y_rad_s": (
                            round(gyro_y, 6)
                            if gyro_y is not None
                            else ""
                        ),
                        "gyro_z_rad_s": (
                            round(gyro_z, 6)
                            if gyro_z is not None
                            else ""
                        ),
                        "gyro_magnitude_rad_s": (
                            round(gyro_magnitude, 6)
                            if gyro_magnitude is not None
                            else ""
                        ),
                        "session_elapsed_s": round(session_elapsed, 4),
                        "activity_label": activity,
                        "target_state": target_state,
                        "use_for_training": use_for_training,
                        "face_detected": int(face_detected),
                        "head_pose_detected": int(
                            head_pose_detected
                        ),
                        "head_pitch_deg": (
                            round(head_pitch, 6)
                            if head_pitch is not None
                            else ""
                        ),
                        "head_yaw_deg": (
                            round(head_yaw, 6)
                            if head_yaw is not None
                            else ""
                        ),
                        "head_roll_deg": (
                            round(head_roll, 6)
                            if head_roll is not None
                            else ""
                        ),
                        "head_movement_magnitude_deg": (
                            round(head_movement_magnitude, 6)
                            if head_movement_magnitude is not None
                            else ""
                        ),
                        "neutral_head_pitch_deg": round(
                            neutral_head_pitch, 6
                        ),
                        "neutral_head_yaw_deg": round(
                            neutral_head_yaw, 6
                        ),
                        "neutral_head_roll_deg": round(
                            neutral_head_roll, 6
                        ),
                        "left_ear": (
                            round(left_ear, 6)
                            if left_ear is not None
                            else ""
                        ),
                        "right_ear": (
                            round(right_ear, 6)
                            if right_ear is not None
                            else ""
                        ),
                        "average_ear": (
                            round(average_ear, 6)
                            if average_ear is not None
                            else ""
                        ),
                        "normalized_ear": (
                            round(normalized_ear, 6)
                            if normalized_ear is not None
                            else ""
                        ),
                        "open_eye_baseline": round(open_baseline, 6),
                        "closed_eye_baseline": round(
                            closed_baseline, 6
                        ),
                        "ear_threshold": round(ear_threshold, 6),
                        "ear_below_threshold": int(
                            eye_state["ear_below_threshold"]
                        ),
                        "eyes_closed": int(
                            eye_state["eyes_closed"]
                        ),
                        "current_closure_duration_ms": (
                            tracker.current_duration_ms
                        ),
                        "last_closure_duration_ms": (
                            tracker.last_duration_ms
                        ),
                        "closure_event": eye_state["closure_event"],
                        "blink_count": tracker.blink_count,
                        "prolonged_closure_count": (
                            tracker.prolonged_count
                        ),
                    }

                    if csv_writer is not None:
                        csv_writer.writerow(row)

                    frame_index += 1

                    if csv_file is not None and frame_index % FPS == 0:
                        csv_file.flush()

                    transition = use_for_training == 0
                    title_colour = (
                        (0, 255, 255)
                        if transition
                        else (0, 0, 255)
                    )

                    put_text(
                        display_frame,
                        f"RECORDING: {activity}",
                        28,
                        title_colour,
                        0.63,
                    )
                    put_text(
                        display_frame,
                        instruction,
                        58,
                        scale=0.44,
                        thickness=1,
                    )
                    put_text(
                        display_frame,
                        f"Segment remaining: {segment_remaining:.1f}s",
                        88,
                    )
                    put_text(
                        display_frame,
                        f"Total remaining: "
                        f"{max(0.0, 120 - session_elapsed):.1f}s",
                        116,
                    )
                    put_text(
                        display_frame,
                        f"Use for training: {use_for_training}",
                        144,
                        (0, 255, 0)
                        if use_for_training
                        else (0, 255, 255),
                    )

                    if average_ear is not None:
                        put_text(
                            display_frame,
                            f"EAR: {average_ear:.3f} | "
                            f"Threshold: {ear_threshold:.3f}",
                            172,
                        )

                    eyes_closed = bool(eye_state["eyes_closed"])
                    eye_status = "CLOSED" if eyes_closed else "OPEN"

                    if (
                        eyes_closed
                        and tracker.current_duration_ms
                        > MAX_BLINK_DURATION_MS
                    ):
                        eye_status = "PROLONGED CLOSURE"

                    put_text(
                        display_frame,
                        f"Eyes: {eye_status} | "
                        f"Blinks: {tracker.blink_count} | "
                        f"Prolonged: {tracker.prolonged_count}",
                        200,
                        (0, 0, 255)
                        if eyes_closed
                        else (0, 255, 0),
                        0.49,
                    )

                    if (
                        head_yaw is not None
                        and head_pitch is not None
                        and head_roll is not None
                    ):
                        put_text(
                            display_frame,
                            f"Head yaw {head_yaw:+.1f} | "
                            f"pitch {head_pitch:+.1f} | "
                            f"roll {head_roll:+.1f}",
                            228,
                            (255, 255, 0),
                            0.48,
                        )
                        put_text(
                            display_frame,
                            "Head movement magnitude: "
                            f"{head_movement_magnitude:.1f} deg",
                            254,
                            (255, 255, 0),
                            0.48,
                        )
                    else:
                        put_text(
                            display_frame,
                            "HEAD POSE NOT DETECTED",
                            228,
                            (0, 0, 255),
                            0.48,
                        )

                imu_ready = (
                    latest_accel is not None
                    and latest_gyro is not None
                )
                missing_imu_streams = []
                if latest_accel is None:
                    missing_imu_streams.append("ACCEL")
                if latest_gyro is None:
                    missing_imu_streams.append("GYRO")

                if imu_ready and not imu_ready_announced:
                    print("\nAccelerometer and gyroscope samples are active.")
                    print("The session may be started after calibration.")
                    imu_ready_announced = True

                imu_status_text = (
                    "IMU READY"
                    if imu_ready
                    else "IMU WAIT: " + "/".join(missing_imu_streams)
                )
                imu_status_colour = (
                    (0, 255, 0)
                    if imu_ready
                    else (0, 200, 255)
                )
                (status_width, _), _ = cv2.getTextSize(
                    imu_status_text,
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.45,
                    1,
                )
                status_x = max(12, OUTPUT_WIDTH - status_width - 16)
                cv2.rectangle(
                    display_frame,
                    (status_x - 8, 6),
                    (OUTPUT_WIDTH - 8, 30),
                    (15, 15, 15),
                    -1,
                )
                cv2.putText(
                    display_frame,
                    imu_status_text,
                    (status_x, 23),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.45,
                    imu_status_colour,
                    1,
                    cv2.LINE_AA,
                )

                if latest_accel is not None:
                    ax, ay, az = latest_accel
                    put_text(
                        display_frame,
                        f"Accel X:{ax:+.2f} Y:{ay:+.2f} Z:{az:+.2f}",
                        OUTPUT_HEIGHT - 72,
                        (255, 200, 0),
                        0.40,
                        1,
                    )

                if latest_gyro is not None:
                    gx, gy, gz = latest_gyro
                    put_text(
                        display_frame,
                        f"Gyro X:{gx:+.3f} Y:{gy:+.3f} Z:{gz:+.3f}",
                        OUTPUT_HEIGHT - 46,
                        (255, 200, 0),
                        0.40,
                        1,
                    )

                put_text(
                    display_frame,
                    "C = closed calibration | S = start | "
                    "R = recalibrate | Q = exit",
                    OUTPUT_HEIGHT - 18,
                    scale=0.42,
                    thickness=1,
                )

                cv2.imshow(WINDOW_TITLE, display_frame)

                key = cv2.waitKey(1) & 0xFF

                if (
                    key == ord("c")
                    and not session_started
                    and calibration_stage == "WAIT_CLOSED"
                ):
                    closed_values.clear()
                    calibration_stage = "CLOSED"
                    calibration_start = time.monotonic()
                    print(
                        "\nClosed-eye calibration started. "
                        "Gently close both eyes."
                    )

                elif (
                    key == ord("s")
                    and not session_started
                    and calibrated
                    and calibration_stage == "DONE"
                    and not imu_ready
                ):
                    print(
                        "\nRecording cannot start yet. Waiting for: "
                        + ", ".join(missing_imu_streams)
                        + "."
                    )

                elif (
                    key == ord("s")
                    and not session_started
                    and calibrated
                    and calibration_stage == "DONE"
                    and imu_ready
                ):
                    csv_file = csv_path.open(
                        "w",
                        newline="",
                        encoding="utf-8",
                    )
                    csv_writer = csv.DictWriter(
                        csv_file,
                        fieldnames=fieldnames,
                    )
                    csv_writer.writeheader()
                    video_writer = create_video_writer(video_path)

                    session_started = True
                    session_start = time.monotonic()
                    frame_index = 0
                    last_segment = ""
                    tracker.reset_all()
                    smoothed_head_pitch = None
                    smoothed_head_yaw = None
                    smoothed_head_roll = None

                    print("\nRecording started.")

                elif (
                    key == ord("r")
                    and not session_started
                ):
                    calibration_stage = "OPEN"
                    calibration_start = time.monotonic()
                    open_values.clear()
                    closed_values.clear()
                    neutral_pitch_values.clear()
                    neutral_yaw_values.clear()
                    neutral_roll_values.clear()
                    neutral_head_pitch = 0.0
                    neutral_head_yaw = 0.0
                    neutral_head_roll = 0.0
                    smoothed_head_pitch = None
                    smoothed_head_yaw = None
                    smoothed_head_roll = None
                    open_baseline = 0.0
                    closed_baseline = 0.0
                    ear_threshold = 0.0
                    calibrated = False

                    print(
                        "\nCalibration restarted. "
                        "Keep eyes naturally open."
                    )

                elif key == ord("q") or key == 27:
                    print("\nSession stopped by user.")
                    break

    except KeyboardInterrupt:
        print("\nProgram interrupted.")

    finally:
        if csv_file is not None:
            csv_file.flush()
            csv_file.close()

        if video_writer is not None:
            video_writer.release()

        try:
            capture.stop()
        except Exception as error:
            print(f"RealSense capture stop warning: {error}")

        cv2.destroyAllWindows()

        print("\nSession closed.")

        if session_started:
            print(f"Rows recorded: {frame_index}")
            print(f"Blinks detected: {tracker.blink_count}")
            print(
                "Prolonged closures detected:",
                tracker.prolonged_count,
            )
            print(f"CSV saved to: {csv_path}")
            print(f"Video saved to: {video_path}")
            print(
                "Status: COMPLETE 120-SECOND SESSION"
                if session_completed
                else "Status: PARTIAL SESSION"
            )


if __name__ == "__main__":
    main()
