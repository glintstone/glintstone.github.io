@echo off
setlocal
cd /d "%~dp0"

py -3.11 --version >nul 2>&1
if errorlevel 1 (
  echo Python 3.11 is required. Install it from python.org, then run this file again.
  pause
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  echo Creating the DRIVE//STATE Windows environment...
  py -3.11 -m venv .venv
  if errorlevel 1 goto :failed
)

call ".venv\Scripts\activate.bat"
python -m pip install --upgrade pip
if errorlevel 1 goto :failed
python -m pip install -r requirements-windows.txt
if errorlevel 1 goto :failed

python live_assessment_windows_rgb_imu_RUN.py
if errorlevel 1 goto :failed
pause
exit /b 0

:failed
echo.
echo The assessment could not start. Review the message above, check the D435i USB connection, and try again.
pause
exit /b 1
