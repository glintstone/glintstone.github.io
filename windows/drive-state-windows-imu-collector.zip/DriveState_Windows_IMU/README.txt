DRIVE//STATE — Windows + Intel RealSense D435i collector
========================================================

Purpose
-------
This research companion records D435i RGB, accelerometer and gyroscope data
together with facial behaviour and calibrated head pose. RGB and IMU streams
are received independently, using their RealSense device timestamps, so the
collector remains usable when a Windows virtual machine cannot assemble a
synchronized RealSense frameset.

Requirements
------------
- Windows 10 or Windows 11, 64 bit
- Python 3.11 installed with the "py" launcher available
- Intel RealSense D435i connected directly through USB 3
- Intel RealSense Viewer closed before starting
- If using Parallels, pass the complete D435i USB device into Windows

Start
-----
1. Extract the ZIP file completely.
2. Double-click install_and_run.bat.
3. The first run creates a local environment and installs dependencies.
4. Follow the metadata and eye/head calibration prompts.
5. Press S only when the participant is ready.

The collector requests RGB at 30 FPS, accelerometer at 63 Hz and gyroscope at
200 Hz. Each RGB record is paired with the newest IMU samples available at that
moment. A preview window opens immediately after the sensors open, then shows
the live RGB feed and an IMU WAIT or IMU READY badge. Calibration may continue
while motion samples arrive, but recording cannot start until both the
accelerometer and gyroscope are ready. If the device or RGB stream cannot be
opened, the session does not start.

Safety and interpretation
-------------------------
Run deliberate eye-closing or head-movement activities only in a parked vehicle
or simulator. This is a university research prototype, not a medical diagnosis
or production-certified vehicle safety system.
